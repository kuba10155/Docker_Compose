# docker_compose

Laboratorium 6, Karol Wos, 7.4/8 Tworzenie aplikacji wielokontenerowych

W celu uruchomienia aplikacji z GitHuba nalezy
 
- wpisac git clone https://github.com/karolwos/docker_compose.git
- wpisac cd docker_compose
- wpisac docker-compose up


Nastepnie nalezy poczekac na wykonanie sie komendy i uruchomienie kontenerow, a nastepnie wejsc w przegladarce na adres localhost:6666
